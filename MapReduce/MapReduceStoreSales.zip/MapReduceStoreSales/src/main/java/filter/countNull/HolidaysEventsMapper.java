package filter.countNull;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class HolidaysEventsMapper extends Mapper<LongWritable, Text, Text, IntWritable> {


	  
	  
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		String[] fields=value.toString().split(",",-1);
		for(int i=0;i<fields.length;i++) {
			if(fields[i].isEmpty() || fields[i].equals(null) || fields[i].equals("")) {
				if(i==0)
					context.write(new Text("HolidaysEvents_date"), new IntWritable(1));
				else if(i==1)
					context.write(new Text("HolidaysEvents_type"), new IntWritable(1));
				else if(i==2)
					context.write(new Text("HolidaysEvents_locale"), new IntWritable(1));
				else if(i==3)
					context.write(new Text("HolidaysEvents_localeName"), new IntWritable(1));
				else if(i==4)
					context.write(new Text("HolidaysEvents_description"), new IntWritable(1));
				else if(i==5)
					context.write(new Text("HolidaysEvents_transferred"), new IntWritable(1));
				
			}
			else {
				if(i==0)
					context.write(new Text("HolidaysEvents_date"), new IntWritable(0));
				else if(i==1)
					context.write(new Text("HolidaysEvents_type"), new IntWritable(0));
				else if(i==2)
					context.write(new Text("HolidaysEvents_locale"), new IntWritable(0));
				else if(i==3)
					context.write(new Text("HolidaysEvents_localeName"), new IntWritable(0));
				else if(i==4)
					context.write(new Text("HolidaysEvents_description"), new IntWritable(0));
				else if(i==5)
					context.write(new Text("HolidaysEvents_transferred"), new IntWritable(0));
			}
			
		}
	
		
	}
	
}
