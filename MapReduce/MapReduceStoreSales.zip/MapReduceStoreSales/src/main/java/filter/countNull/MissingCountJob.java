package filter.countNull;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



/**
 * Hello world!
 *
 */
public class MissingCountJob 
{
    public static void main( String[] args )
    {
    			Configuration conf = new Configuration();
    			try {
    				Job j = Job.getInstance(conf,"MissingCountJob");
    				j.setJarByClass(MissingCountJob.class);
    				//j.setMapperClass(ClusterMapper.class);
    				j.setReducerClass(MissingCountReducer.class);
    				j.setMapOutputKeyClass(Text.class);
    				j.setMapOutputValueClass(IntWritable.class);
    				
    				MultipleInputs.addInputPath(j, new Path("store_sales/train"),
    			            TextInputFormat.class, TrainMapper.class);
    			    MultipleInputs.addInputPath(j, new Path("store_sales/stores"),
    			            TextInputFormat.class, StoreMapper.class);
    			    MultipleInputs.addInputPath(j, new Path("store_sales/oil"),
    			            TextInputFormat.class, OilMapper.class);
    			    MultipleInputs.addInputPath(j, new Path("store_sales/test"),
    			            TextInputFormat.class, TestMapper.class);
    			    MultipleInputs.addInputPath(j, new Path("store_sales/transactions"),
    			            TextInputFormat.class, TransactionMapper.class);
    			    MultipleInputs.addInputPath(j, new Path("store_sales/holidays_events"),
    			            TextInputFormat.class, HolidaysEventsMapper.class);
    				FileOutputFormat.setOutputPath(j, new Path("count_null_values"));			
    				j.waitForCompletion(true);
    				
    				
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (ClassNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (InterruptedException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    }
}
