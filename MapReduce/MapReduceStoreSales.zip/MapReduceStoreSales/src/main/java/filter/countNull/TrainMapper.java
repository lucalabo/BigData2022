package filter.countNull;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class TrainMapper extends Mapper<LongWritable, Text, Text, IntWritable> {


	  
	  
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		String[] fields=value.toString().split(",",-1);
		for(int i=0;i<fields.length;i++) {
			if(fields[i].isEmpty() || fields[i].equals(null) || fields[i].equals("")) {
				if(i==0)
					context.write(new Text("Train_id"), new IntWritable(1));
				else if(i==1)
					context.write(new Text("Train_date"), new IntWritable(1));
				else if(i==2)
					context.write(new Text("Train_storeNbr"), new IntWritable(1));
				else if(i==3)
					context.write(new Text("Train_family"), new IntWritable(1));
				else if(i==4)
					context.write(new Text("Train_sales"), new IntWritable(1));
				else if(i==5)
					context.write(new Text("Train_onPromotion"), new IntWritable(1));
				
			}
			else {
				if(i==0)
					context.write(new Text("Train_id"), new IntWritable(0));
				else if(i==1)
					context.write(new Text("Train_date"), new IntWritable(0));
				else if(i==2)
					context.write(new Text("Train_storeNbr"), new IntWritable(0));
				else if(i==3)
					context.write(new Text("Train_family"), new IntWritable(0));
				else if(i==4)
					context.write(new Text("Train_sales"), new IntWritable(0));
				else if(i==5)
					context.write(new Text("Train_onPromotion"), new IntWritable(0));
			}

		}
	
		
	}

	
	
}
