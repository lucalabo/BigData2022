package filter.countNull;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class StoreMapper extends Mapper<LongWritable, Text, Text, IntWritable> {


	

	  
	  
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		String[] fields=value.toString().split(",",-1);
		for(int i=0;i<fields.length;i++) {
			if(fields[i].isEmpty() || fields[i].equals(null) || fields[i].equals("")) {
				if(i==0)
					context.write(new Text("Stores_storeNbr"), new IntWritable(1));
				else if(i==1)
					context.write(new Text("Stores_city"), new IntWritable(1));
				else if(i==2)
					context.write(new Text("Stores_state"), new IntWritable(1));
				else if(i==3)
					context.write(new Text("Stores_type"), new IntWritable(1));
				else if(i==4)
					context.write(new Text("Stores_cluster"), new IntWritable(1));
				
			}
			else {
				if(i==0)
					context.write(new Text("Stores_storeNbr"), new IntWritable(0));
				else if(i==1)
					context.write(new Text("Stores_city"), new IntWritable(0));
				else if(i==2)
					context.write(new Text("Stores_state"), new IntWritable(0));
				else if(i==3)
					context.write(new Text("Stores_type"), new IntWritable(0));
				else if(i==4)
					context.write(new Text("Stores_cluster"), new IntWritable(0));
			}
		}
	
		
	}

	
}
