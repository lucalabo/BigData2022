package filter.family;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class FamilyFilterReducer extends Reducer<Text, Text, Text, NullWritable> {
	
	@Override
	protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, NullWritable>.Context context)
			throws IOException, InterruptedException {
		Float sales=0f;
		Float promotion=0f;
		String s="";
		for(Text value: values) {
			String[] fields=value.toString().split(",");
			promotion+=Float.parseFloat(fields[3].toString());
			sales+=Float.parseFloat(fields[2].toString());
			s=value.toString();
		}
		String[] fields=s.split(",");
		s=fields[0]+","+fields[1]+","+sales+","+promotion;
		context.write(new Text(s), null);
		
	}

}
