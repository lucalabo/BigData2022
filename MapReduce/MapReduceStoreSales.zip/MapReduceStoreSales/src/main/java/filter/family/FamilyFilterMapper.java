package filter.family;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class FamilyFilterMapper extends Mapper<LongWritable, Text, Text, Text> {


	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		String[] fields=value.toString().split(",");
		String newVal="";
		if(fields[3].equals("PREPARED FOODS") || fields[3].equals("GROCERY I") || fields[3].equals("BREAD/BAKERY") || fields[3].equals("GROCERY II") 
			 || fields[3].equals("SEAFOOD") || fields[3].equals("DELI") || fields[3].equals("POULTRY") || fields[3].equals("FROZEN FOODS") 
			 || fields[3].equals("EGGS") || fields[3].equals("MEATS") || fields[3].equals("DAIRY")) {
			newVal=fields[1].toString()+",FOOD,"+fields[4].toString()+","+fields[5].toString();				
			context.write(new Text(fields[1]+",FOOD"),new Text(newVal));
		}
		else if(fields[3].equals("BEVERAGES") || fields[3].equals('"'+"LIQUOR")) {
				newVal=fields[1].toString()+",DRINK,"+fields[4].toString()+","+fields[5].toString();				
				context.write(new Text(fields[1]+",DRINK"),new Text(newVal));
		}
		else if(fields[3].equals("BOOKS") || fields[3].equals("CELEBRATION") || fields[3].equals("MAGAZINES") 
				|| fields[3].equals("PLAYERS AND ELECTRONICS") || fields[3].equals("LAWN AND GARDEN")) {
			newVal=fields[1].toString()+",HOBBY,"+fields[4].toString()+","+fields[5].toString();				
			context.write(new Text(fields[1]+",HOBBY"),new Text(newVal));
		}
		else if(fields[3].equals("BABY CARE") || fields[3].equals("LINGERIE") || fields[3].equals("BEAUTY") 
				|| fields[3].equals("LADIESWEAR") || fields[3].equals("PERSONAL CARE") ) {
			newVal=fields[1].toString()+",PERSONAL CARE,"+fields[4].toString()+","+fields[5].toString();				
			context.write(new Text(fields[1]+",PERSONAL CARE"),new Text(newVal));
		}
		else if(fields[3].equals("HOME AND KITCHEN I") || fields[3].equals("HOME AND KITCHEN II") || fields[3].equals("HOME APPLIANCES") 
				|| fields[3].equals("HOME CARE") || fields[3].equals("CLEANING") ) {
			newVal=fields[1].toString()+",HOME CARE,"+fields[4].toString()+","+fields[5].toString();				
			context.write(new Text(fields[1]+",HOME CARE"),new Text(newVal));
		}
		else {
			newVal=fields[1].toString()+",OTHER,"+fields[4].toString()+","+fields[5].toString();	
			context.write(new Text(fields[1]+",OTHER"),new Text(newVal));
		}
		
		
	}
	
	
}
