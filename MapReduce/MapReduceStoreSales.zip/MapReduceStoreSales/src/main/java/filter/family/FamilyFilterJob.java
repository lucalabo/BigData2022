package filter.family;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



/**
 * Hello world!
 *
 */
public class FamilyFilterJob 
{
    public static void main( String[] args )
    {
    			Configuration conf = new Configuration();
    			try {
    				Job j = Job.getInstance(conf,"FamilyFiltering");
    				j.setJarByClass(FamilyFilterJob.class);
    		
    				j.setMapperClass(FamilyFilterMapper.class);
    				
    				j.setReducerClass(FamilyFilterReducer.class);
    				
    				j.setMapOutputKeyClass(Text.class);
    				j.setMapOutputValueClass(Text.class);
    				
    				FileInputFormat.addInputPath(j, new Path("store_sales/train"));
    				
    				FileOutputFormat.setOutputPath(j, new Path("store_sales_filter/grouped"));
    			    				
    				j.waitForCompletion(true);
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (ClassNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (InterruptedException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    }
}
