package filter.cluster;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CluterReducer extends Reducer<Text, Text, NullWritable, Text> {
	
	@Override
	protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, NullWritable, Text>.Context context)
			throws IOException, InterruptedException {
		ArrayList<Text> store=new ArrayList<Text>();
		ArrayList<Text> train=new ArrayList<Text>();
		String nameCluster="";
		for(Text value : values) {
			String[] fields=value.toString().split(",");
		    if(fields[0].equals("STORE")) {
		    	store.add(new Text(fields[1]));
		    }
		    else
		    	train.add(new Text(fields[1]+","+fields[2]+","+fields[3]+","+fields[4]));
		}
		
		for(Text st: store) {
			for(Text tr:train) {
				String[] fields=tr.toString().split(",");
				context.write(NullWritable.get(),new Text(tr.toString()+","+st.toString()));
			}
		}
	}
}
