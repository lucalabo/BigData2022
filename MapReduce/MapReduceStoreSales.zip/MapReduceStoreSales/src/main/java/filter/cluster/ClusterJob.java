package filter.cluster;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



/**
 * Hello world!
 *
 */
public class ClusterJob 
{
    public static void main( String[] args )
    {
    			Configuration conf = new Configuration();
    			try {
    				Job j = Job.getInstance(conf,"JoinTrainStore");
    				j.setJarByClass(ClusterJob.class);
    				//j.setMapperClass(ClusterMapper.class);
    				j.setReducerClass(CluterReducer.class);
    				j.setMapOutputKeyClass(Text.class);
    				j.setMapOutputValueClass(Text.class);
    				MultipleInputs.addInputPath(j, new Path("store_sales/train"),
    			            TextInputFormat.class, ClusterMapper.class);

    			    MultipleInputs.addInputPath(j, new Path("store_sales/stores"),
    			            TextInputFormat.class, StoreMapper.class);
    				FileOutputFormat.setOutputPath(j, new Path("store_train_joined"));			
    				j.waitForCompletion(true);
    				
    				Job j2=Job.getInstance(conf,"groupyByClusterAndDate");
    				j2.setMapperClass(GroupByMapper.class);
    				j2.setReducerClass(GroupByReducer.class);
    				j2.setMapOutputKeyClass(Text.class);
    				j2.setMapOutputValueClass(Text.class);
    				FileInputFormat.addInputPath(j2, new Path("store_train_joined"));
    				FileOutputFormat.setOutputPath(j2, new Path("store_sales_filter/groupedByCluster"));
    				j2.setJarByClass(ClusterJob.class);
    				j2.waitForCompletion(true);
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (ClassNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (InterruptedException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    }
}
