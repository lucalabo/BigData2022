package filter.cluster;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class GroupByReducer extends Reducer<Text,Text, Text, Text> {
	
	@Override
	protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		Float sales=0f;
		Float promotion=0f;
		String s="";
		String[] temp=key.toString().split(",");
		for(Text value: values) {
			String[] fields=value.toString().split(",");
			promotion+=Float.parseFloat(fields[1].toString());
			sales+=Float.parseFloat(fields[0].toString());
		}
		//String[] fields=s.split(",");
		s=temp[0]+","+temp[1]+","+sales+","+promotion;
		context.write(new Text(s), null);
	}

}
