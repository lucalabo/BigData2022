package filter.cluster;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class GroupByMapper extends Mapper<LongWritable, Text, Text, Text> {
	
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		String[] fields=value.toString().split(",");
		String newVal=fields[2].toString()+","+fields[3].toString();
		context.write(new Text(fields[1].toString()+","+fields[4].toString()),new Text(newVal.toString()));

	}

}
