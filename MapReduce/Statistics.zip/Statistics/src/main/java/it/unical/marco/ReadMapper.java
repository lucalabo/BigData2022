package it.unical.marco;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ReadMapper extends Mapper<Object, Text, Text, Text>
{
    @Override
    protected void map(final Object key, final Text value, final Mapper<Object, Text, Text, Text>.Context context)
            throws IOException, InterruptedException
    {
        // 0 id, 1 date, 2 store number, 3 family, 4 sales, 5 onpromotion
        final String[] values = value.toString().split(","); //$NON-NLS-1$

        context.write(new Text("id"), new Text(values[0])); //$NON-NLS-1$
        context.write(new Text("store_number"), new Text(values[2])); //$NON-NLS-1$
        context.write(new Text("sales"), new Text(values[4])); //$NON-NLS-1$
        context.write(new Text("onpromotion"), new Text(values[5])); //$NON-NLS-1$
    }
}
