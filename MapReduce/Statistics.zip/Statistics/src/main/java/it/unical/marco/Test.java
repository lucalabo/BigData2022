package it.unical.marco;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Test
{

    public static void main(final String[] args)
    {
        final Configuration conf = new Configuration();

        try
        {
            final Job j = Job.getInstance(conf, "statistics"); //$NON-NLS-1$
            j.setJarByClass(Test.class);

            // HDFS MAPPER
            j.setMapperClass(ReadMapper.class);
            FileInputFormat.addInputPath(j, new Path("store_sales/train")); //$NON-NLS-1$
            j.setMapOutputKeyClass(Text.class);
            j.setMapOutputValueClass(Text.class);

            // HDFS REDUCER
            j.setReducerClass(StoreReducer.class);
            FileOutputFormat.setOutputPath(j, new Path("store_sales/statistics")); //$NON-NLS-1$

            j.waitForCompletion(true);
        }
        catch (final Exception e)
        {
            e.printStackTrace();
        }
    }
}
