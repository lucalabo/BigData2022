package it.unical.marco;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class StoreReducer extends Reducer<Text, Text, Text, Text>
{

    @Override
    protected void reduce(final Text key, final Iterable<Text> values, final Reducer<Text, Text, Text, Text>.Context context)
            throws IOException, InterruptedException
    {

        int cont = 0;
        Double min = null;
        Double max = null;
        Double average = 0.0;

        for (final Text value : values)
        {

            final Double attribute = Double.valueOf(value.toString());

            cont++;

            if (cont == 1)
            {
                min = attribute;
                max = attribute;
            }
            else
            {
                if (attribute < min)
                {
                    min = attribute;
                }
                if (attribute > max)
                {
                    max = attribute;
                }
            }

            average += attribute;

        }

        context.write(key, new Text(cont + "," + min + "," + max + "," + average / cont)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    }
}
